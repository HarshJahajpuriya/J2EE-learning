package com.webservice.hammerprice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.webservice.hammerprice.hibernate.Authority;

public interface AuthorityRepository extends JpaRepository<Authority, Long> {
}