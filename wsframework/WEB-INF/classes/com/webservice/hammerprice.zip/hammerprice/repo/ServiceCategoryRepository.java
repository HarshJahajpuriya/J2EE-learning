package com.webservice.hammerprice.repo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.util.LinkedList;
import java.util.List;

import com.webservice.hammerprice.hibernate.HibernateUtil;
import com.webservice.hammerprice.hibernate.ServiceCategory;

public class ServiceCategoryRepository {
  public static List<ServiceCategory> findAll() {
    List<ServiceCategory> serviceCategories = new LinkedList<>();
    try {
      HibernateUtil hibernateUtil = new HibernateUtil();
      Session session = hibernateUtil.getSessionFactory().getCurrentSession();
      session.beginTransaction();

      serviceCategories = session.createQuery("from service_category").list();

      session.getTransaction().commit();
    } catch (Exception exception) {
      System.out.println("ServiceCategoryRepository : "+exception);
    }    
    return serviceCategories;
  }
}
