package com.webservice.hammerprice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.webservice.hammerprice.hibernate.User;

public interface UserRepository extends JpaRepository<User, Long> {
}
