package com.webservice.hammerprice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.webservice.hammerprice.hibernate.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {
}