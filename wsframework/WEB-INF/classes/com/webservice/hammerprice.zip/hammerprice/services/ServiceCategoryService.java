package com.webservice.hammerprice.services;

import com.webservice.framework.annotations.Path;
import com.webservice.hammerprice.repo.ServiceCategoryRepository;

@Path("/serviceCategory")
public class ServiceCategoryService {

  @Path("getAll")
  public Object getAll() {
    try {
      return ServiceCategoryRepository.findAll();
    } catch(Exception exception) {
      return exception;
    }
  }    

}
